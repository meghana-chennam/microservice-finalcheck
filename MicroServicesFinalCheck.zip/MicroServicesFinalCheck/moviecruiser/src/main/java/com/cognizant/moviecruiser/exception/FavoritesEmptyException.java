package com.cognizant.moviecruiser.exception;

public class FavoritesEmptyException extends Exception{

	public FavoritesEmptyException(String msg) {
		super(msg);
	}
}
